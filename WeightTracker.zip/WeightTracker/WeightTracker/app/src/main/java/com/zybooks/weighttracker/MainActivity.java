package com.zybooks.weighttracker;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * MainActivity controls the full Weight Tracker application.
 *
 * This class handles:
 * - User login and account creation
 * - Navigation between UI screens
 * - SQLite create, read, update, and delete operations
 * - Goal weight storage and display
 * - Optional SMS permission and goal notification
 */
public class MainActivity extends AppCompatActivity {

    // Database helper object used for all SQLite operations.
    private DatabaseHelper databaseHelper;

    // Stores the currently logged-in user's database ID.
    // A value of -1 means no user is currently logged in.
    private int currentUserId = -1;

    // Stores the ID of the weight entry currently being edited.
    // A value of -1 means the user is adding a new entry instead of editing one.
    private int editingWeightId = -1;

    // Tracks whether the user has granted SMS permission.
    private boolean smsPermissionGranted = false;

    // Handles the Android runtime permission request for sending SMS messages.
    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         * Create the database helper.
         * This also gives the app access to the users, weights, and goals tables.
         */
        databaseHelper = new DatabaseHelper(this);

        /*
         * Register the SMS permission launcher.
         * After the user chooses Allow or Deny, the app automatically continues
         * to the Weight Log screen because SMS permission is optional.
         */
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    smsPermissionGranted = isGranted;

                    Toast.makeText(
                            this,
                            isGranted ? "SMS permission granted" : "SMS permission denied",
                            Toast.LENGTH_SHORT
                    ).show();

                    // Continue automatically after the permission choice.
                    showWeightLogScreen();
                }
        );

        // The application starts on the login screen.
        showLoginScreen();
    }

    /**
     * Displays the login screen and handles login and account creation.
     */
    private void showLoginScreen() {
        setContentView(R.layout.activity_login);

        // Connect Java variables to the XML views on the login screen.
        EditText usernameInput = findViewById(R.id.editTextUsername);
        EditText passwordInput = findViewById(R.id.editTextPassword);
        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);

        /*
         * Login button:
         * Checks the entered username and password against the users table.
         * If the login is valid, the user's ID is stored and the app moves forward.
         */
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Basic validation prevents empty login attempts.
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Query the database to see if this username/password combination exists.
            int userId = databaseHelper.loginUser(username, password);

            if (userId == -1) {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            } else {
                currentUserId = userId;
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                // After login, the user is asked whether they want SMS notifications.
                showSmsPermissionScreen();
            }
        });

        /*
         * Create Account button:
         * Inserts a new username and password into the users table.
         * Duplicate usernames are prevented by the database helper.
         */
        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Basic validation prevents blank accounts from being created.
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = databaseHelper.createUser(username, password);

            if (created) {
                Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Displays the SMS permission screen.
     * SMS permission is optional. If the user enables SMS, Android asks for permission.
     * After the user allows or denies permission, the app automatically moves to the
     * Weight Log screen. The user can also continue without enabling SMS.
     */
    private void showSmsPermissionScreen() {
        setContentView(R.layout.activity_sms_permission);

        // Connect Java variables to the XML views on the SMS permission screen.
        Button enableSmsButton = findViewById(R.id.buttonEnableSms);
        Button continueButton = findViewById(R.id.buttonContinueToWeightLog);
        Button backButton = findViewById(R.id.buttonBackToLogin);
        TextView statusText = findViewById(R.id.textViewSmsStatus);

        /*
         * Check whether SMS permission is already granted.
         * This updates the visible status message before the user makes a choice.
         */
        smsPermissionGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;

        if (smsPermissionGranted) {
            statusText.setText("Permission Status: Enabled");
        } else {
            statusText.setText("Permission Status: Not Enabled");
        }

        /*
         * Enable SMS button:
         * If permission is already granted, go straight to the Weight Log.
         * If permission is not granted, request it. The permission launcher will
         * automatically continue to the Weight Log after the user chooses Allow or Deny.
         */
        enableSmsButton.setOnClickListener(v -> {
            if (smsPermissionGranted) {
                showWeightLogScreen();
            } else {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        /*
         * Continue button:
         * Allows the user to skip SMS permission and continue using the app.
         */
        continueButton.setOnClickListener(v -> showWeightLogScreen());

        /*
         * Back button:
         * Returns to the login screen.
         */
        backButton.setOnClickListener(v -> showLoginScreen());
    }

    /**
     * Displays the main weight log screen.
     *
     * This screen is the user's home screen after logging in. It shows the user's
     * current goal weight, displays all saved weight entries from the SQLite database,
     * and provides buttons for adding a new weight, setting a goal weight, or logging out.
     */
    private void showWeightLogScreen() {
        // Load the weight log XML layout.
        setContentView(R.layout.activity_weight_log);

        // Connect Java variables to the buttons in activity_weight_log.xml.
        Button addWeightButton = findViewById(R.id.buttonAddWeight);
        Button setGoalButton = findViewById(R.id.buttonSetGoal);
        Button logoutButton = findViewById(R.id.buttonLogout);

        /*
         * Load the user's saved goal weight and saved weight entries.
         * These methods read from the SQLite database and update the UI.
         */
        refreshGoalDisplay();
        refreshWeightTable();

        /*
         * Add Daily Weight button:
         * Opens the Add / Update Weight screen in add mode.
         * editingWeightId is set to -1 to show that this is a new entry,
         * not an update to an existing database record.
         */
        addWeightButton.setOnClickListener(v -> {
            editingWeightId = -1;
            showAddWeightScreen("", "");
        });

        /*
         * Set Goal Weight button:
         * Opens a dialog where the user can enter or update their goal weight.
         * The goal value is saved to the SQLite database.
         */
        setGoalButton.setOnClickListener(v -> showSetGoalDialog());

        /*
         * Log Out / Back to Login button:
         * Clears the current user and any edit state, then returns to the login screen.
         */
        logoutButton.setOnClickListener(v -> {
            currentUserId = -1;
            editingWeightId = -1;
            showLoginScreen();
        });
    }

    /**
     * Reads the current user's goal weight from the database and displays it.
     */
    private void refreshGoalDisplay() {
        TextView goalText = findViewById(R.id.textViewGoalWeight);

        double goalWeight = databaseHelper.getGoalWeight(currentUserId);

        if (goalWeight == -1) {
            goalText.setText("Goal Weight: Not Set");
        } else {
            goalText.setText("Goal Weight: " + goalWeight + " lbs");
        }
    }

    /**
     * Reads all saved weight entries for the current user and displays them in the table.
     *
     * This method satisfies the READ part of CRUD.
     */
    private void refreshWeightTable() {
        TableLayout table = findViewById(R.id.tableWeightLog);

        /*
         * Keep the header row and remove any old data rows.
         * This prevents duplicate rows from appearing every time the table refreshes.
         */
        while (table.getChildCount() > 1) {
            table.removeViewAt(1);
        }

        Cursor cursor = databaseHelper.getWeightsForUser(currentUserId);

        /*
         * Loop through the database results and create a table row for each record.
         */
        while (cursor.moveToNext()) {
            int weightId = cursor.getInt(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT_ID)
            );

            String date = cursor.getString(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.COL_DATE)
            );

            double weight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT)
            );

            TableRow row = new TableRow(this);
            row.setBackgroundColor(Color.WHITE);

            TextView dateText = createTableText(date);
            TextView weightText = createTableText(weight + " lbs");

            /*
             * Edit button:
             * Opens the add/update screen with the selected record already filled in.
             * This prepares the app for the UPDATE part of CRUD.
             */
            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setTextSize(12);
            editButton.setOnClickListener(v -> {
                editingWeightId = weightId;
                showAddWeightScreen(date, String.valueOf(weight));
            });

            /*
             * Delete button:
             * Removes the selected weight entry from the database.
             * This satisfies the DELETE part of CRUD.
             */
            Button deleteButton = new Button(this);
            deleteButton.setText("X");
            deleteButton.setTextSize(12);
            deleteButton.setTextColor(Color.WHITE);
            deleteButton.setBackgroundColor(Color.rgb(176, 0, 32));
            deleteButton.setOnClickListener(v -> {
                databaseHelper.deleteWeight(weightId);
                Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();

                // Refresh the table so the deleted row disappears.
                refreshWeightTable();
            });

            // Add all row components in the same order as the table headers.
            row.addView(dateText);
            row.addView(weightText);
            row.addView(editButton);
            row.addView(deleteButton);

            table.addView(row);
        }

        cursor.close();
    }

    /**
     * Creates a TextView used inside the weight table.
     *
     * @param text the text to display in the table cell
     * @return a formatted TextView
     */
    private TextView createTableText(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        textView.setGravity(Gravity.CENTER_VERTICAL);
        textView.setTextColor(Color.BLACK);

        /*
         * Weight of 1 allows each table cell to share available row space evenly.
         */
        textView.setLayoutParams(new TableRow.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1
        ));

        return textView;
    }

    /**
     * Validates that a date is entered in MM/DD/YYYY format.
     *
     * Examples of accepted dates:
     * - 06/16/2026
     * - 12/01/2026
     *
     * @param date the date text entered by the user
     * @return true if the date matches MM/DD/YYYY format, false otherwise
     */
    private boolean isValidDateFormat(String date) {
        return date.matches("^(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/\\d{4}$");
    }

    /**
     * Displays the add/update weight screen.
     *
     * If editingWeightId is -1, the screen creates a new record.
     * If editingWeightId has a database ID, the screen updates that existing record.
     *
     * @param date existing date value if editing, or blank if adding
     * @param weight existing weight value if editing, or blank if adding
     */
    private void showAddWeightScreen(String date, String weight) {
        setContentView(R.layout.activity_add_weight);

        EditText dateInput = findViewById(R.id.editTextDate);
        EditText weightInput = findViewById(R.id.editTextWeight);
        Button saveButton = findViewById(R.id.buttonSaveWeight);
        Button backButton = findViewById(R.id.buttonCancelAddWeight);

        // If editing an existing record, pre-fill the fields with saved data.
        dateInput.setText(date);
        weightInput.setText(weight);

        /*
         * Save Entry button:
         * Either inserts a new record or updates an existing one.
         * This satisfies the CREATE and UPDATE parts of CRUD.
         */
        saveButton.setOnClickListener(v -> {
            String enteredDate = dateInput.getText().toString().trim();
            String enteredWeight = weightInput.getText().toString().trim();

            // Validate that both fields contain data.
            if (enteredDate.isEmpty() || enteredWeight.isEmpty()) {
                Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate the date before saving so all records use the same format.
            if (!isValidDateFormat(enteredDate)) {
                Toast.makeText(this, "Date must be in MM/DD/YYYY format", Toast.LENGTH_SHORT).show();
                return;
            }

            double weightValue;

            // Convert the weight string to a number and reject invalid input.
            try {
                weightValue = Double.parseDouble(enteredWeight);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Weight must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success;

            /*
             * If editingWeightId is -1, add a new row.
             * Otherwise, update the selected database record.
             */
            if (editingWeightId == -1) {
                success = databaseHelper.addWeight(currentUserId, enteredDate, weightValue);
            } else {
                success = databaseHelper.updateWeight(editingWeightId, enteredDate, weightValue);
            }

            if (success) {
                /*
                 * After saving a weight entry, compare it to the user's goal.
                 * If the goal is reached and SMS is enabled, the app attempts an SMS alert.
                 */
                checkGoalReached(weightValue);

                editingWeightId = -1;
                Toast.makeText(this, "Entry saved", Toast.LENGTH_SHORT).show();
                showWeightLogScreen();
            } else {
                Toast.makeText(this, "Entry could not be saved", Toast.LENGTH_SHORT).show();
            }
        });

        // Return to the main weight log without saving.
        backButton.setOnClickListener(v -> {
            editingWeightId = -1;
            showWeightLogScreen();
        });
    }

    /**
     * Displays a dialog that allows the user to set or update their goal weight.
     */
    private void showSetGoalDialog() {
        EditText input = new EditText(this);
        input.setHint("Goal Weight");

        /*
         * Restrict input to numbers and decimals because goal weight should be numeric.
         */
        input.setInputType(
                android.text.InputType.TYPE_CLASS_NUMBER |
                        android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        );

        new AlertDialog.Builder(this)
                .setTitle("Set Goal Weight")
                .setMessage("Enter your goal weight.")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    String value = input.getText().toString().trim();

                    if (value.isEmpty()) {
                        Toast.makeText(this, "Goal weight not saved", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        double goalWeight = Double.parseDouble(value);

                        // Save or update the user's goal weight in SQLite.
                        databaseHelper.saveGoalWeight(currentUserId, goalWeight);

                        Toast.makeText(this, "Goal weight saved", Toast.LENGTH_SHORT).show();

                        // Reload the weight log so the displayed goal updates.
                        showWeightLogScreen();
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Goal must be a number", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Checks whether a saved weight entry reaches the user's goal weight.
     *
     * If the current weight is less than or equal to the goal weight, the app shows a toast.
     * If SMS permission is granted, the app also attempts to send an SMS notification.
     *
     * @param currentWeight the weight value just saved by the user
     */
    private void checkGoalReached(double currentWeight) {
        double goalWeight = databaseHelper.getGoalWeight(currentUserId);

        // No goal has been set, so there is nothing to compare.
        if (goalWeight == -1) {
            return;
        }

        /*
         * For this weight-loss style tracker, reaching the goal means the recorded
         * weight is less than or equal to the target goal weight.
         */
        if (currentWeight <= goalWeight) {
            Toast.makeText(this, "Goal weight reached!", Toast.LENGTH_LONG).show();

            /*
             * Only send an SMS if the user granted permission.
             * The phone number is a placeholder for the course project demonstration.
             */
            if (smsPermissionGranted) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();

                    smsManager.sendTextMessage(
                            "5551234567",
                            null,
                            "Congratulations! Your goal weight has been reached.",
                            null,
                            null
                    );
                } catch (Exception e) {
                    Toast.makeText(this, "SMS could not be sent", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}